//
//  DLLocalNotifications.h
//  DLLocalNotifications
//
//  Created by Devesh Laungani on 12/14/16.
//  Copyright © 2016 Devesh Laungani. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DLLocalNotifications.
FOUNDATION_EXPORT double DLLocalNotificationsVersionNumber;

//! Project version string for DLLocalNotifications.
FOUNDATION_EXPORT const unsigned char DLLocalNotificationsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DLLocalNotifications/PublicHeader.h>


